<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>My Favorite Candy</title>
  <link rel="stylesheet" href="style.css">
</head>
<body>
  <header>
    <nav>
      <ul>
        <li><a href="#">Home</a></li>
        <li><a href="#">About</a></li>
        <li><a href="#">Contact</a></li>
      </ul>
    </nav>
  </header>
  <main>
    <section>
      <h1>My Favorite Candy is M&M</h1>
      <article>
        <h2>About the Candy</h2>
        <p>M&M's were first introduced in 1941 by Forrest Mars Sr. in the United States. The candy was initially created as a convenient snack for soldiers during World War II due to its ability to withstand high temperatures without melting. The "M&M" name stands for "Mars & Murrie's," which refers to the partnership between Forrest Mars Sr. and Bruce Murrie, the son of Hershey Chocolate's president at the time.

Over the years, M&M's has expanded its product line to include a variety of flavors, colors, and fillings. The original M&M's featured a milk chocolate filling, but today, you can find M&M's with peanut butter, crispy rice, pretzel, caramel, and other flavors.

In addition to the classic milk chocolate version, M&M's are available in various colors and seasonal editions. They have become a popular treat for holidays like Halloween and Christmas, often featuring colors and designs associated with those occasions.

M&M's are widely loved and enjoyed by people of all ages, and the brand has become synonymous with fun and indulgence. The candy is often used in baking, dessert toppings, and even as a decorative element in cakes and cookies.

Please note that while I can provide general information about M&M's, I do not have access to specific details about individuals associated with the brand, such as "M&M James."</p>
      </article>
      <article>
        <h2>Nutritional Information</h2>
        <p>Here is the general nutritional information for classic M&M's milk chocolate candies, based on a serving size of 1.69 ounces (47.9 grams), which is approximately one small bag:

Calories: 240
Total Fat: 9 grams
Saturated Fat: 5 grams
Trans Fat: 0 grams
Cholesterol: 5 milligrams
Sodium: 30 milligrams
Total Carbohydrate: 34 grams
Dietary Fiber: 1 gram
Sugars: 30 grams
Protein: 2 grams</p>
      </article>
    </section>
    <aside>
    
    </aside>
  </main>
  <footer>
    <div class="logo">
      <img src="M&M.png" alt="Company logo">
    </div>
    <div class="company-info">
      
    </div>
    <div class="contact-form">
      <h3>Contact Us</h3>
      <form>
        <label for="name">Name:</label>
        <input type="text" id="name" name="name"><br><br>
        <label for="email">Email:</label>
        <input type="email" id="email" name="email"><br><br>
        <label for="message">Message:</label>
        <textarea id="message" name="message"></textarea><br><br>
        <input type="submit" value="Submit">
      </form>

    </div>
  </footer>
</body>
</html>